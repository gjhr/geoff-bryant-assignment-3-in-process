//
//  DetailViewController.swift
//  Assignment3SecondTry
//
//  Created by Geoff Bryant on 7/25/16.
//  Copyright © 2016 Geoff Bryant. All rights reserved.
//
//
//
//make a protocol
//declare a delegate property w/in the class of the protocolo type
//set the delegate property of the other VC (main VC) to self
//conform to protocol in the other/main VC

//protocol recipeProtocol {
//
//}

import Foundation


import UIKit

// IBOUTLER VARS?


class DetailViewController: UIViewController {
    
//    var delegate: recipeDelegate?
    
    @IBOutlet weak var recipeNameLabel: UILabel!
    
    @IBOutlet weak var cookTimeLabel: UILabel!
    
    @IBOutlet weak var recipeDescriptionLabel: UILabel!
    
 
    @IBOutlet weak var ingredientsLabel: UILabel!
    
    @IBOutlet weak var stepsLabel: UILabel!
    
    
    @IBOutlet weak var testLabel: UILabel!
    
 
    @IBOutlet weak var testLabel2: UILabel!
    
 
    
    var recipeCFS: RecipeObject!
    
//    weak var delegate: DetailViewControllerDelegate?
    
//    recipeNameLabel.text = RecipeObject.recipeName.String
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        print(recipeCFS?.recipeName)
                recipeNameLabel?.text = recipeCFS?.recipeName
                cookTimeLabel?.text = recipeCFS?.cookTime
                recipeDescriptionLabel?.text = recipeCFS?.recipeDescription
                ingredientsLabel?.text = recipeCFS?.ingredients
                stepsLabel?.text = recipeCFS?.steps
        stepsLabel.text = "eat me"
        cookTimeLabel.text = "fuck you"
           testLabel.text = " fuck fuck fuck"
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        recipeNameLabel?.text = recipeCFS?.recipeName
//        cookTimeLabel.text = recipeCFS?.cookTime
        recipeDescriptionLabel.text = recipeCFS?.recipeDescription
        ingredientsLabel.text = recipeCFS?.ingredients
//        stepsLabel.text = recipeCFS?.steps
stepsLabel.text = "eat me"
        cookTimeLabel.text = "fuck you"
           testLabel?.text = " fuck fuck fuck"
    }
    
    
  
}
