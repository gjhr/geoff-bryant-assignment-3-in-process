//
//  ImageTestTableViewCell.swift
//  Assignment3SecondTry
//
//  Created by Geoff Bryant on 7/28/16.
//  Copyright © 2016 Geoff Bryant. All rights reserved.
//

import UIKit

class ImageTestTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
