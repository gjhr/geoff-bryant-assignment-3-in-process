//
//  MainListTableViewController.swift
//  Assignment3SecondTry
//
//  Created by Geoff Bryant on 7/24/16.
//  Copyright © 2016 Geoff Bryant. All rights reserved.
//

import Foundation

import UIKit

class MainListTableViewController: UITableViewController {
    
    private var recipes = [RecipeObject]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    
        
        
        
        
        
        let recipeItems = [
            RecipeObject(recipeName: "OJ", cookTime: "a few minutes", recipeDescription: "A beverage?  A sociopath?  A beveragopath?", ingredients: "orange", steps: "Squeeze orange(s) until liquid comes out.  Probably helpful to cut in half first.  The orange, not you, silly.", recipeImage: UIImage(named: "OJ")!),
            RecipeObject(recipeName: "Toast", cookTime:  "3-5 minutes", recipeDescription: "It's toast; bread you kinda sorta almost hopefully didn't complete burn", ingredients: "Bread.  Anything you want to put on said bread.", steps: "Get bread.  Apply heat.  Apply eat.", recipeImage: UIImage(named: "toast")!),
            RecipeObject(recipeName: "PB&J", cookTime: "N/A", recipeDescription: "A classic staple of modern american cuisine", ingredients: "Bread, peanut butter, jelly.  Staples, if you're into that.", steps: "It puts the peanut butter and jelly on the bread or else it gets the hose again.", recipeImage: UIImage(named: "PBJ")!),
            RecipeObject(recipeName: "Soup. Or not soup.", cookTime: "depends on how much wood you put on the fire", recipeDescription: "Andy Warhol", ingredients: "soup, aluminium, can opener", steps: "Open the can, stick it over the fire, eat when warm.  What a jolly boring thing to do.", recipeImage: UIImage(named: "soup")!),
            RecipeObject(recipeName: "Pizza", cookTime: "depends on how long it takes to get to Patsy's", recipeDescription: "...if it's good enough for Sinatra...", ingredients: "Pizza, box", steps: "Open the box, grab the pizza, eat the pizza, repeat.  Repizza.", recipeImage: UIImage(named: "pizza")!)
        ]
        
        recipes.appendContentsOf(recipeItems)
        
    }
  
   
//        
//    }
    // need to make the detialviewcontroller then go into prepareforsegue
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "detailsegueID" {
        if let DetailViewController = segue.destinationViewController as? DetailViewController {
//            DetailViewController.delegate = self
            if let indexpath = tableView.indexPathForSelectedRow {
                let recipeCFS = recipes[indexpath.row]
                
                DetailViewController.recipeCFS = recipeCFS
            }
            
            }
        }
    }
    
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return recipes.count
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("maincellID", forIndexPath: indexPath)
        
        // CONNECT CELL ID TO STORYBOARD!!!!!!
        
        let recipeCFS = recipes[indexPath.row]
        cell.textLabel?.text = recipeCFS.recipeName
        cell.detailTextLabel?.text = recipeCFS.recipeDescription
        cell.imageView!.frame = CGRectMake(0,0,32,32)
        cell.imageView?.image = recipeCFS.recipeImage
        
        
//       func tableView(tableView: UITableView, didSelectRowAtIndexPath: NSIndexPath)
//        if let cell = tableView.cellForRowAtIndexPath(indexPath),
//        let destinationViewController
        
        
        return cell
    }
    
    
}


