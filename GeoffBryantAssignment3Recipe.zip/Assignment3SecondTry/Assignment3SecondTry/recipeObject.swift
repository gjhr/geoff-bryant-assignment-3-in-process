//
//  recipeObject.swift
//  Assignment3SecondTry
//
//  Created by Geoff Bryant on 7/24/16.
//  Copyright © 2016 Geoff Bryant. All rights reserved.
//

import Foundation

import UIKit

class RecipeObject: NSObject {
    
    let recipeName: String
    let cookTime: String
    let recipeDescription: String
    let ingredients: String
    let steps: String
    let recipeImage: UIImage
//    let image: UIImage
    
    init(recipeName: String, cookTime: String, recipeDescription: String, ingredients: String, steps: String, recipeImage: UIImage) {
        self.recipeName = recipeName
        self.cookTime = cookTime
//        self.cookTime = "nothing"
        self.recipeDescription = recipeDescription
        self.ingredients = ingredients
        self.steps = steps
        self.recipeImage = recipeImage
    }
}
